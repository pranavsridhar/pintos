struct bitmap swap_table;
struct block swap_block;